<?php
include('db_connection.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);

$search = $data['search'] ?? '';
$searchColumn = $data['searchColumn'] ?? ''; // New parameter for specific column search
$sortColumn = $data['sortColumn'] ?? 'Payment_id';
$sortDirection = $data['sortDirection'] ?? 'asc';
$selectedColumns = $data['selectedColumns'] ?? ['Payment_id', 'Tenancy_id', 'Payment_date'];

// Prepare the columns to display
$columns = implode(", ", $selectedColumns);

// Determine the search column (if any) or default to searching all columns
if ($searchColumn) {
    // If a specific column is selected for search, filter based on that column
    $sql = "SELECT $columns FROM PAYMENTS WHERE $searchColumn LIKE ? ORDER BY $sortColumn $sortDirection";
} else {
    // If no specific column is chosen, search across all selected columns
    $sql = "SELECT $columns FROM PAYMENTS WHERE CONCAT_WS('', $columns) LIKE ? ORDER BY $sortColumn $sortDirection";
}

$stmt = $conn->prepare($sql);
$searchTerm = "%" . $search . "%";
$stmt->bind_param("s", $searchTerm);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

header("Content-Type: application/json");
echo json_encode($data);

$conn->close();
?>
